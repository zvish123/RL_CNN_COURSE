#!/usr/bin/env python3
"""Classroom vote and exit-ticket server for the Asimov lesson closing."""
import argparse
import csv
import io
import json
import secrets
import sqlite3
import threading
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parent
HTML = ROOT / 'סיום השיעור מי מחליט על AI.html'

def main():
    parser = argparse.ArgumentParser(description='Asimov closing classroom server')
    parser.add_argument('--port', type=int, default=8766)
    parser.add_argument('--host', default='0.0.0.0')
    parser.add_argument('--db', default=str(ROOT / 'closing_answers.sqlite3'))
    args = parser.parse_args()
    pin = str(secrets.randbelow(900000) + 100000)
    teacher_session = secrets.token_urlsafe(32)
    lock = threading.RLock()
    db = sqlite3.connect(args.db, check_same_thread=False)
    db.execute('CREATE TABLE IF NOT EXISTS votes (client TEXT PRIMARY KEY, choice INTEGER NOT NULL)')
    db.execute('CREATE TABLE IF NOT EXISTS tickets (client TEXT PRIMARY KEY, demand TEXT NOT NULL, reason TEXT NOT NULL)')
    db.commit()

    class Handler(BaseHTTPRequestHandler):
        def cookies(self):
            c = SimpleCookie()
            try: c.load(self.headers.get('Cookie', ''))
            except Exception: pass
            return c

        def identity(self):
            c = self.cookies()
            if 'closing_id' in c and len(c['closing_id'].value) <= 100:
                return c['closing_id'].value, None
            token = secrets.token_urlsafe(32)
            return token, f'closing_id={token}; Path=/; HttpOnly; SameSite=Lax'

        def teacher(self):
            c = self.cookies()
            return 'closing_teacher' in c and secrets.compare_digest(c['closing_teacher'].value, teacher_session)

        def respond(self, status, data, typ='application/json; charset=utf-8', cookie=None, extra=None):
            if isinstance(data, str): data = data.encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', typ)
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(data)))
            if cookie: self.send_header('Set-Cookie', cookie)
            if extra:
                for key,value in extra.items(): self.send_header(key,value)
            self.end_headers(); self.wfile.write(data)

        def payload(self):
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 0 <= size <= 2048: return None
                obj = json.loads(self.rfile.read(size))
                return obj if isinstance(obj, dict) else None
            except (ValueError, UnicodeDecodeError): return None

        def do_GET(self):
            path = urlsplit(self.path).path
            if path == '/':
                return self.respond(200, HTML.read_bytes(), 'text/html; charset=utf-8')
            if path == '/teacher':
                form = '''<!doctype html><html lang="he" dir="rtl"><meta charset="utf-8"><title>כניסת מורה</title><body style="font:20px Arial;margin:10vh auto;max-width:480px"><h1>כניסת מורה</h1><p>הזינו את הקוד שמופיע בחלון השרת.</p><form method="post" action="/teacher"><input name="pin" type="password" inputmode="numeric" required><button>כניסה</button></form></body></html>'''
                return self.respond(200,form,'text/html; charset=utf-8')
            if path == '/api/state':
                client,cookie = self.identity()
                with lock:
                    counts=[0,0,0,0]
                    for choice,n in db.execute('SELECT choice,COUNT(*) FROM votes GROUP BY choice'):
                        if choice in range(4): counts[choice]=n
                    vote=db.execute('SELECT choice FROM votes WHERE client=?',(client,)).fetchone()
                    ticket=db.execute('SELECT 1 FROM tickets WHERE client=?',(client,)).fetchone()
                return self.respond(200,json.dumps({'counts':counts,'voted':vote[0] if vote else None,'ticketSubmitted':bool(ticket),'teacher':self.teacher()}),cookie=cookie)
            if path == '/api/tickets':
                if not self.teacher(): return self.respond(403,'{}')
                with lock: entries=[{'demand':d,'reason':r} for d,r in db.execute('SELECT demand,reason FROM tickets ORDER BY rowid')]
                return self.respond(200,json.dumps(entries,ensure_ascii=False))
            if path == '/api/export':
                if not self.teacher(): return self.respond(403,'{}')
                out=io.StringIO();writer=csv.writer(out);writer.writerow(['דרישה','נימוק'])
                with lock: writer.writerows(db.execute('SELECT demand,reason FROM tickets ORDER BY rowid'))
                return self.respond(200,'\ufeff'+out.getvalue(),'text/csv; charset=utf-8',extra={'Content-Disposition':'attachment; filename="asimov-exit-tickets.csv"'})
            return self.respond(404,'{}')

        def do_POST(self):
            path=urlsplit(self.path).path
            if path == '/teacher':
                size=min(int(self.headers.get('Content-Length','0')),100)
                value=parse_qs(self.rfile.read(size).decode('utf-8')).get('pin',[''])[0]
                if not secrets.compare_digest(value,pin): return self.respond(403,'קוד שגוי','text/plain; charset=utf-8')
                self.send_response(303)
                self.send_header('Set-Cookie',f'closing_teacher={teacher_session}; Path=/; HttpOnly; SameSite=Strict')
                self.send_header('Location','/')
                self.end_headers();return
            data=self.payload()
            if data is None: return self.respond(400,'{}')
            if path == '/api/vote':
                choice=data.get('choice')
                if type(choice) is not int or choice not in range(4): return self.respond(400,'{}')
                client,cookie=self.identity()
                with lock:
                    cur=db.execute('INSERT OR IGNORE INTO votes VALUES (?,?)',(client,choice));db.commit()
                return self.respond(200 if cur.rowcount else 409,json.dumps({'accepted':bool(cur.rowcount)}),cookie=cookie)
            if path == '/api/ticket':
                demand,reason=data.get('demand'),data.get('reason')
                if not isinstance(demand,str) or not isinstance(reason,str) or not 3<=len(demand.strip())<=300 or not 3<=len(reason.strip())<=500:
                    return self.respond(400,'{}')
                client,cookie=self.identity()
                with lock:
                    cur=db.execute('INSERT OR IGNORE INTO tickets VALUES (?,?,?)',(client,demand.strip(),reason.strip()));db.commit()
                return self.respond(200 if cur.rowcount else 409,json.dumps({'accepted':bool(cur.rowcount)}),cookie=cookie)
            if path == '/api/reset':
                if not self.teacher(): return self.respond(403,'{}')
                kind=data.get('kind')
                if kind not in ('votes','tickets'): return self.respond(400,'{}')
                with lock: db.execute(f'DELETE FROM {kind}');db.commit()
                return self.respond(200,'{"reset":true}')
            return self.respond(404,'{}')

    server=ThreadingHTTPServer((args.host,args.port),Handler)
    print(f'קישור לתלמידים: http://<כתובת ה-IP של המורה>:{args.port}/',flush=True)
    print(f'כניסת מורה: http://localhost:{args.port}/teacher',flush=True)
    print(f'קוד מורה: {pin}',flush=True)
    print('עצירה: Ctrl+C',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:server.server_close();db.close()

if __name__=='__main__':main()
