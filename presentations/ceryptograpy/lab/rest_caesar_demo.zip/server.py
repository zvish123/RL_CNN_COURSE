from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import json


def caesar_encrypt(text, shift):
    result = ""
    for char in text:
        if 'a' <= char <= 'z':
            result += chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
        elif 'A' <= char <= 'Z':
            result += chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
        else:
            result += char
    return result


class MyHandler(BaseHTTPRequestHandler):
    def send_json(self, data, status_code=200):
        body = json.dumps(data).encode('utf-8')
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path
        params = parse_qs(parsed_url.query)

        if path == '/status':
            self.send_json({'status': 'running'})
        elif path == '/encrypt':
            text = params.get('text', [''])[0]
            shift_text = params.get('shift', ['3'])[0]
            try:
                shift = int(shift_text)
            except ValueError:
                self.send_json({'error': 'shift must be an integer'}, 400)
                return
            if not text:
                self.send_json({'error': 'text is required'}, 400)
                return
            encrypted = caesar_encrypt(text, shift)
            self.send_json({'original': text, 'encrypted': encrypted, 'shift': shift})
        else:
            self.send_json({'error': 'Endpoint not found'}, 404)


if __name__ == '__main__':
    server = HTTPServer(('127.0.0.1', 8000), MyHandler)
    print('Server running on http://127.0.0.1:8000')
    server.serve_forever()
