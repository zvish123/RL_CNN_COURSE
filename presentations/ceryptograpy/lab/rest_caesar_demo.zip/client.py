import requests

BASE_URL = 'http://127.0.0.1:8000'

try:
    response = requests.get(f'{BASE_URL}/status', timeout=5)
    response.raise_for_status()
    print('Server status:', response.json())

    response = requests.get(
        f'{BASE_URL}/encrypt',
        params={'text': 'Hello World', 'shift': 3},
        timeout=5
    )
    response.raise_for_status()
    data = response.json()
    print('Original:', data['original'])
    print('Encrypted:', data['encrypted'])
    print('Shift:', data['shift'])
except requests.RequestException as exc:
    print('Request failed:', exc)
