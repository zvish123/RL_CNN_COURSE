REST API demo for Grade 10
1. Open terminal in this folder.
2. Run: python server.py
3. In another terminal, install requests if needed: python -m pip install requests
4. Run: python client.py
5. Browser: http://127.0.0.1:8000/status
6. Browser: http://127.0.0.1:8000/encrypt?text=abc&shift=3
The server binds to localhost only. For classroom LAN, adapt the binding and firewall deliberately.
