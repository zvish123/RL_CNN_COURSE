#!/usr/bin/env python3
"""Local classroom voting server for the Asimov presentation."""
import argparse
import json
import secrets
import sqlite3
import threading
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
HTML = ROOT / 'פתיחה אסימוב האם הייתם סומכים על רובוט.html'
POLLS = {'robbie', 'runaround', 'liar'}

def main():
    parser = argparse.ArgumentParser(description='Asimov class presentation server')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--host', default='0.0.0.0')
    parser.add_argument('--db', default=str(ROOT / 'class_votes.sqlite3'))
    args = parser.parse_args()
    pin = f'{secrets.randbelow(900000)+100000}'
    teacher_session = secrets.token_urlsafe(32)
    lock = threading.RLock()
    db = sqlite3.connect(args.db, check_same_thread=False)
    db.execute('CREATE TABLE IF NOT EXISTS votes (client TEXT, poll TEXT, choice INTEGER, PRIMARY KEY(client,poll))')
    db.commit()

    class Handler(BaseHTTPRequestHandler):
        def cookies(self):
            c = SimpleCookie()
            try: c.load(self.headers.get('Cookie', ''))
            except Exception: pass
            return c

        def identity(self):
            c = self.cookies()
            if 'class_id' in c and len(c['class_id'].value) <= 100:
                return c['class_id'].value, None
            token = secrets.token_urlsafe(32)
            return token, f'class_id={token}; Path=/; HttpOnly; SameSite=Lax'

        def teacher(self):
            c = self.cookies()
            return 'teacher_session' in c and secrets.compare_digest(c['teacher_session'].value, teacher_session)

        def respond(self, status, data, content_type='application/json; charset=utf-8', cookie=None):
            data = data if isinstance(data, bytes) else data.encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(data)))
            if cookie: self.send_header('Set-Cookie', cookie)
            self.end_headers()
            self.wfile.write(data)

        def payload(self):
            size = int(self.headers.get('Content-Length', '0'))
            if size > 2048: return None
            try: return json.loads(self.rfile.read(size))
            except (ValueError, UnicodeDecodeError): return None

        def do_GET(self):
            path = urlsplit(self.path).path
            if path == '/':
                self.respond(200, HTML.read_bytes(), 'text/html; charset=utf-8')
            elif path == '/teacher':
                form = '''<!doctype html><html lang="he" dir="rtl"><meta charset="utf-8"><title>כניסת מורה</title><body style="font:20px Arial;margin:10vh auto;max-width:480px"><h1>כניסת מורה</h1><p>הזינו את הקוד שמופיע בחלון השרת במחשב המורה.</p><form method="post" action="/teacher"><input name="pin" type="password" inputmode="numeric" required><button>כניסה</button></form></body></html>'''
                self.respond(200, form, 'text/html; charset=utf-8')
            elif path == '/api/state':
                client, cookie = self.identity()
                with lock:
                    counts = {p: [0, 0, 0] for p in POLLS}
                    for poll, choice, n in db.execute('SELECT poll,choice,COUNT(*) FROM votes GROUP BY poll,choice'):
                        if poll in counts and choice in (0, 1, 2): counts[poll][choice] = n
                    voted = {p: r[0] for p in POLLS if (r := db.execute('SELECT choice FROM votes WHERE client=? AND poll=?', (client,p)).fetchone()) is not None}
                self.respond(200, json.dumps({'counts': counts, 'voted': voted, 'teacher': self.teacher()}), cookie=cookie)
            else: self.respond(404, '{}')

        def do_POST(self):
            path = urlsplit(self.path).path
            if path == '/teacher':
                size = min(int(self.headers.get('Content-Length', '0')), 100)
                from urllib.parse import parse_qs
                value = parse_qs(self.rfile.read(size).decode('utf-8')).get('pin', [''])[0]
                if not secrets.compare_digest(value, pin):
                    return self.respond(403, 'קוד שגוי', 'text/plain; charset=utf-8')
                self.send_response(303)
                self.send_header('Set-Cookie', f'teacher_session={teacher_session}; Path=/; HttpOnly; SameSite=Strict')
                self.send_header('Location', '/')
                self.end_headers()
                return
            data = self.payload()
            if not isinstance(data, dict): return self.respond(400, '{}')
            if path == '/api/vote':
                poll, choice = data.get('poll'), data.get('choice')
                if poll not in POLLS or type(choice) is not int or choice not in (0, 1, 2):
                    return self.respond(400, '{"error":"invalid_vote"}')
                client, cookie = self.identity()
                with lock:
                    cur = db.execute('INSERT OR IGNORE INTO votes VALUES (?,?,?)', (client,poll,choice))
                    db.commit()
                self.respond(200 if cur.rowcount else 409, json.dumps({'accepted': bool(cur.rowcount)}), cookie=cookie)
            elif path == '/api/reset':
                if not self.teacher(): return self.respond(403, '{"error":"teacher_only"}')
                poll = data.get('poll')
                if poll not in POLLS: return self.respond(400, '{}')
                with lock:
                    db.execute('DELETE FROM votes WHERE poll=?', (poll,))
                    db.commit()
                self.respond(200, '{"reset":true}')
            else: self.respond(404, '{}')

    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f'קישור לתלמידים: http://<כתובת ה-IP של מחשב המורה>:{args.port}/', flush=True)
    print(f'כניסת מורה: http://localhost:{args.port}/teacher', flush=True)
    print(f'קוד מורה: {pin}', flush=True)
    print('עצירה: Ctrl+C', flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close(); db.close()

if __name__ == '__main__': main()
